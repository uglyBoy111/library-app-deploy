// 管理员页面脚本文件
document.addEventListener('DOMContentLoaded', function () {
    // 确认删除用户
    const deleteButtons = document.querySelectorAll('button[onclick*="confirm"]');
    deleteButtons.forEach(button => {
        button.addEventListener('click', function (e) {
            if (!confirm('确定要删除这个用户吗？此操作不可恢复！')) {
                e.preventDefault();
                return false;
            }
        });
    });

    // 添加用户搜索功能
    addUserSearchInterface();

    // 初始化表格排序
    initTableSorting();
});

// 添加用户搜索界面
function addUserSearchInterface() {
    // 找到卡片主体
    const cardBody = document.querySelector('.card-body');
    if (!cardBody) return;

    // 创建搜索界面
    const searchDiv = document.createElement('div');
    searchDiv.className = 'mb-4';
    searchDiv.innerHTML = `
        <div class="card mb-3">
            <div class="card-body">
                <form id="userSearchForm" class="mb-2">
                    <div class="input-group">
                        <input type="text" id="userSearchInput" class="form-control" placeholder="输入ID、学号或关键词搜索..." aria-label="搜索用户">
                        <button class="btn btn-primary" type="submit">
                            <i class="bi bi-search"></i> 搜索
                        </button>
                        <button class="btn btn-outline-secondary" type="button" id="clearUserSearch">
                            <i class="bi bi-x"></i> 清除
                        </button>
                        <button class="btn btn-outline-info" type="button" id="advancedSearchToggle">
                            <i class="bi bi-chevron-down"></i> 高级搜索
                        </button>
                    </div>
                    
                    <div id="advancedSearchOptions" class="mt-3 d-none">
                        <div class="row">
                            <div class="col-md-6 mb-2">
                                <label for="filterUserRole" class="form-label">用户身份</label>
                                <select id="filterUserRole" class="form-select">
                                    <option value="">全部身份</option>
                                    <option value="管理员">管理员</option>
                                    <option value="普通用户">普通用户</option>
                                </select>
                            </div>
                            <div class="col-md-6 mb-2">
                                <label for="filterUserDate" class="form-label">注册时间</label>
                                <select id="filterUserDate" class="form-select">
                                    <option value="">全部时间</option>
                                    <option value="today">今天</option>
                                    <option value="week">本周</option>
                                    <option value="month">本月</option>
                                    <option value="year">今年</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </form>
                
                <div id="searchResultsInfo" class="d-none">
                    <div class="alert alert-info">
                        找到 <strong id="searchResultCount">0</strong> 个匹配的用户
                    </div>
                </div>
                
                <div id="noSearchResults" class="alert alert-warning d-none">
                    <i class="bi bi-exclamation-triangle-fill me-2"></i>没有找到匹配的用户
                </div>
            </div>
        </div>
    `;

    // 将搜索界面插入到表格前面
    const tableResponsive = cardBody.querySelector('.table-responsive');
    if (tableResponsive) {
        cardBody.insertBefore(searchDiv, tableResponsive);

        // 初始化搜索功能
        initUserSearch();
    }
}

// 初始化用户搜索功能
function initUserSearch() {
    const userSearchInput = document.getElementById('userSearchInput');
    const userTable = document.querySelector('.table');
    const userSearchForm = document.getElementById('userSearchForm');
    const clearSearchButton = document.getElementById('clearUserSearch');
    const advancedSearchToggle = document.getElementById('advancedSearchToggle');
    const advancedSearchOptions = document.getElementById('advancedSearchOptions');
    const searchResultsInfo = document.getElementById('searchResultsInfo');
    const searchResultCount = document.getElementById('searchResultCount');
    const noSearchResults = document.getElementById('noSearchResults');

    if (!userSearchInput || !userTable) return;

    // 实时搜索
    userSearchInput.addEventListener('input', function () {
        filterUserTable();
    });

    // 表单提交处理
    userSearchForm.addEventListener('submit', function (e) {
        e.preventDefault();
        filterUserTable();
    });

    // 清除搜索
    clearSearchButton.addEventListener('click', function () {
        userSearchInput.value = '';

        // 重置高级搜索选项
        const filterRole = document.getElementById('filterUserRole');
        const filterDate = document.getElementById('filterUserDate');
        if (filterRole) filterRole.value = '';
        if (filterDate) filterDate.value = '';

        filterUserTable();
        userSearchInput.focus();
    });

    // 高级搜索切换
    advancedSearchToggle.addEventListener('click', function () {
        advancedSearchOptions.classList.toggle('d-none');

        // 更新按钮文本
        const isHidden = advancedSearchOptions.classList.contains('d-none');
        this.innerHTML = isHidden ?
            '<i class="bi bi-chevron-down"></i> 高级搜索' :
            '<i class="bi bi-chevron-up"></i> 收起高级搜索';
    });

    // 高级搜索选项变更时也触发过滤
    const filterUserRole = document.getElementById('filterUserRole');
    const filterUserDate = document.getElementById('filterUserDate');

    if (filterUserRole) {
        filterUserRole.addEventListener('change', filterUserTable);
    }

    if (filterUserDate) {
        filterUserDate.addEventListener('change', filterUserTable);
    }

    // 过滤用户表格
    function filterUserTable() {
        const searchTerm = userSearchInput.value.toLowerCase().trim();
        const roleFilter = filterUserRole ? filterUserRole.value.toLowerCase() : '';
        const dateFilter = filterUserDate ? filterUserDate.value : '';

        const rows = userTable.querySelectorAll('tbody tr');
        let visibleRowCount = 0;

        rows.forEach(row => {
            // 基础文本匹配
            const text = row.textContent.toLowerCase();
            const matchesSearch = !searchTerm || text.includes(searchTerm);

            // 角色过滤
            let matchesRole = true;
            if (roleFilter) {
                const roleCell = row.querySelector('td:nth-child(3)');
                if (roleCell) {
                    if (roleFilter === '管理员') {
                        matchesRole = roleCell.textContent.includes('管理员');
                    } else if (roleFilter === '普通用户') {
                        matchesRole = roleCell.textContent.includes('普通用户');
                    }
                }
            }

            // 日期过滤
            let matchesDate = true;
            if (dateFilter) {
                const dateCell = row.querySelector('td:nth-child(4)');
                if (dateCell) {
                    const dateText = dateCell.textContent.trim();
                    const userDate = new Date(dateText);
                    const now = new Date();

                    // 确保是有效的日期
                    if (!isNaN(userDate.getTime())) {
                        if (dateFilter === 'today') {
                            // 今天
                            matchesDate = userDate.toDateString() === now.toDateString();
                        } else if (dateFilter === 'week') {
                            // 本周 (过去7天)
                            const weekAgo = new Date();
                            weekAgo.setDate(now.getDate() - 7);
                            matchesDate = userDate >= weekAgo;
                        } else if (dateFilter === 'month') {
                            // 本月
                            matchesDate = userDate.getMonth() === now.getMonth() &&
                                userDate.getFullYear() === now.getFullYear();
                        } else if (dateFilter === 'year') {
                            // 今年
                            matchesDate = userDate.getFullYear() === now.getFullYear();
                        }
                    }
                }
            }

            // 综合所有过滤条件
            if (matchesSearch && matchesRole && matchesDate) {
                row.style.display = '';
                visibleRowCount++;
            } else {
                row.style.display = 'none';
            }
        });

        // 更新结果信息
        if (searchTerm || roleFilter || dateFilter) {
            searchResultsInfo.classList.remove('d-none');
            searchResultCount.textContent = visibleRowCount;

            if (visibleRowCount === 0) {
                noSearchResults.classList.remove('d-none');
            } else {
                noSearchResults.classList.add('d-none');
            }
        } else {
            searchResultsInfo.classList.add('d-none');
            noSearchResults.classList.add('d-none');
        }
    }
}

// 初始化表格排序功能
function initTableSorting() {
    const table = document.querySelector('.table');
    if (!table) return;

    const headers = table.querySelectorAll('thead th');
    const tbody = table.querySelector('tbody');

    if (!headers || !tbody) return;

    // 给每个表头添加排序功能（除了"操作"列）
    headers.forEach((header, index) => {
        // 跳过"操作"列
        if (header.textContent.trim() === '操作') return;

        // 添加排序样式和点击事件
        header.style.cursor = 'pointer';
        header.classList.add('sortable');
        header.setAttribute('data-sort-direction', 'none');

        // 添加排序指示器
        const sortIndicator = document.createElement('span');
        sortIndicator.className = 'sort-indicator ms-1';
        sortIndicator.innerHTML = '<i class="bi bi-arrow-down-up"></i>';
        header.appendChild(sortIndicator);

        // 添加点击事件
        header.addEventListener('click', function () {
            sortTable(index);
        });
    });

    // 存储原始行顺序
    const rows = tbody.querySelectorAll('tr');
    rows.forEach((row, index) => {
        row.setAttribute('data-original-index', index);
    });

    // 排序表格函数
    function sortTable(columnIndex) {
        const header = headers[columnIndex];
        const currentDirection = header.getAttribute('data-sort-direction');
        let newDirection = 'asc';

        if (currentDirection === 'asc') {
            newDirection = 'desc';
        } else if (currentDirection === 'desc') {
            newDirection = 'none';
        }

        // 重置所有表头
        headers.forEach(h => {
            h.setAttribute('data-sort-direction', 'none');
            const indicator = h.querySelector('.sort-indicator');
            if (indicator) {
                indicator.innerHTML = '<i class="bi bi-arrow-down-up"></i>';
            }
        });

        // 设置当前表头
        header.setAttribute('data-sort-direction', newDirection);

        // 更新排序指示器
        const indicator = header.querySelector('.sort-indicator');
        if (indicator) {
            if (newDirection === 'asc') {
                indicator.innerHTML = '<i class="bi bi-sort-alpha-down"></i>';
            } else if (newDirection === 'desc') {
                indicator.innerHTML = '<i class="bi bi-sort-alpha-up"></i>';
            } else {
                indicator.innerHTML = '<i class="bi bi-arrow-down-up"></i>';
            }
        }

        // 获取所有行并排序
        const rows = Array.from(tbody.querySelectorAll('tr'));

        if (newDirection === 'none') {
            // 恢复原始顺序
            rows.sort((a, b) => {
                return parseInt(a.getAttribute('data-original-index')) -
                    parseInt(b.getAttribute('data-original-index'));
            });
        } else {
            // 按指定列排序
            rows.sort((a, b) => {
                const cellA = a.cells[columnIndex].textContent.trim();
                const cellB = b.cells[columnIndex].textContent.trim();

                // 检查是否为数字
                const numA = parseFloat(cellA);
                const numB = parseFloat(cellB);

                if (!isNaN(numA) && !isNaN(numB)) {
                    // 数字排序
                    return newDirection === 'asc' ? numA - numB : numB - numA;
                } else {
                    // 文本排序
                    const comparison = cellA.localeCompare(cellB, 'zh-CN');
                    return newDirection === 'asc' ? comparison : -comparison;
                }
            });
        }

        // 重新附加行到表格
        rows.forEach(row => tbody.appendChild(row));
    }
}